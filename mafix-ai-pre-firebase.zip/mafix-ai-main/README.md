# Mafix AI

Flutter front end for Mafix AI, using the existing Cloudflare Worker chat endpoint.

## Current project status
- Existing AI chat integration retained at `https://mafix-ai-backend.idrisatijjani9.workers.dev/chat`.
- Added login/register screens and form validation as a **UI prototype**.
- Added Free, Pro Monthly, Pro Yearly, and Free Trial plan preview screen.
- Added navigation to plans and account preview from chat.

## Important before public release
Authentication is NOT connected yet. The current login/register screen does not create or verify accounts and does not persist credentials. Connect Firebase Authentication or Supabase Auth before using real accounts or publishing this as a production app. Do not collect real passwords until that is done.

Subscription checkout is also NOT active. Prices, trial length, entitlements, and subscription rules still need to be decided. Before accepting money, implement payment initialization and server-side verification in the backend; never unlock Pro solely from a client-side success message. Review Google Play Billing requirements for digital features before publishing.

## Build
Use Flutter stable (Dart SDK >=3.3.0 <4.0.0):

```bash
flutter pub get
flutter analyze
flutter build apk --release
```

The GitHub Actions workflow can build an APK when pushed to the configured repository.
